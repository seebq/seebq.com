#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <stdio.h>

/* you may need to locate glut.h on your computer and change the path accordingly.
 * It is most likely in ~/include or ~include/GL.
 */

/* the viewport is 500x500 with the origin at (0,0) */
int Vx_min=0, Vx_max=500, Vy_min=0, Vy_max=500, Vz_min=0, Vz_max=0;

void init(void) 
{
   glClearColor (0.0, 0.0, 0.0, 0.0);
}

void show(int array_x[], int array_y[], int color)
{
  int i;

  if (color == 1) {
    /* red */
    glColor3ub(255,0,0); /* params are unsigned bytes in range [0,255] */
  }
  else if (color == 2) {
    /* green */
    glColor3ub(0,255,0); /* params are unsigned bytes in range [0,255] */
  }
  else if (color == 3) {
    /* blue */
    glColor3ub(0,0,255); /* params are unsigned bytes in range [0,255] */
  }
  glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
  glBegin(GL_POLYGON);
  for (i = 0; i < sizeof(array_x); i++) {
    glVertex2s(array_x[i], array_y[i]);
  }
  glEnd();
}

void midpoints(int m_array[], int array[])
{ 
  int i;
  
  for (i = 0; i < sizeof(array) - 1; i++) {
    m_array[i] = (array[i] + array[i+1]) / 2;
  } 
  m_array[i] = (array[i] + array[0]) / 2;

}

void movefourth(int a_array[], int array[])
{ 
  int i;
  int prev;
  int curr;
  int next;

  for (i = sizeof(array); i < (sizeof(array) * 2); i++) {
    prev = (i - 1) % sizeof(array);
    curr = i % sizeof(array);
    next = (i + 1) % sizeof(array);
    a_array[i] = (prev / 8) + (next / 8) + (curr * (3 / 4));
  }  

}

void display(void)
{
  int n = 4;
  int v_array_x[n];
  int v_array_y[n];
  int m_array_x[n];
  int m_array_y[n];
  int a_array_x[n];
  int a_array_y[n];
  int s_array_x[2*n];
  int s_array_y[2*n];

  v_array_x[0] = 125;
  v_array_y[0] = 125;
  v_array_x[1] = 375;
  v_array_y[1] = 125;
  v_array_x[2] = 375;
  v_array_y[2] = 375;
  v_array_x[3] = 125;
  v_array_y[3] = 375;

  glClear (GL_COLOR_BUFFER_BIT);   

  show(v_array_x, v_array_y, 1);
  midpoints(m_array_x, v_array_x);
  midpoints(m_array_y, v_array_y);
  show(m_array_x, m_array_y, 2);
  movefourth(a_array_x, v_array_x);
  movefourth(a_array_y, v_array_y);
  show(a_array_x, a_array_y, 3);

  glFlush ();
}

void reshape (int w, int h)
{
   glViewport (0, 0, (GLsizei) w, (GLsizei) h); 
   glMatrixMode (GL_PROJECTION);
   glLoadIdentity ();
   gluOrtho2D(Vx_min, Vx_max, Vy_min, Vy_max);
   glMatrixMode (GL_MODELVIEW);

}
void mouse(int button, int state, int x, int y)
{

   switch (button) {
      case GLUT_LEFT_BUTTON:
		  if (state == GLUT_DOWN) {
			printf("left mouse click\n");
			glutPostRedisplay();
		  }
         break;
      default:
         break;
   }
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
   glutInitWindowSize (Vx_max-Vx_min, Vy_max-Vy_min); 
   glutInitWindowPosition (100, 100);
   glutCreateWindow (argv[0]);
   
   init ();

   glutDisplayFunc(display); 
   glutReshapeFunc(reshape);
   glutMouseFunc(mouse);
   glutMainLoop();
   return 0;
}
