/*FileSmoother.c - reads in file, smooths*/
/*Brandon Yarbrough, Team Greenlee*/

#include <stdio.h>
#include <stdlib.h>

#include "shape.h"


Shape createShape(int numVertices, int numTris)
{
	Shape newShape;
       
	newShape = malloc(sizeof(Shape_Typ));
	newShape->vTable = malloc(sizeof(float)*3*numVertices);
	newShape->tTable = malloc(sizeof(int)*3*numTris);
	if(newShape->vTable == NULL || newShape->tTable == NULL)
		printf("ahhh\n!");
	newShape->numVertices = numVertices;
	newShape->numTris = numTris;
	return newShape;
}

void destroyShape(Shape shape)
{
	free(shape->vTable);
	free(shape->tTable);
	free(shape);
}

Shape readShapeFromFile(char* fileName)
{
	Shape shape;
	FILE* file;
	int numVertices=-1;
	char inputString[5];
	int i;
	int numTris;

	file = fopen(fileName,"r");

	if(file == NULL)
	{
		fprintf(stderr,"Read error!\n");
		return NULL;
	}

	/*first line is just BSV1*/
	
	if(fscanf(file,"%4[^\n]\n",inputString) == EOF)
	{
		fprintf(stderr,"File Read error!!\n");
		return NULL;
	}

	if(strcmp(inputString,"BSV2"))
	{
		fprintf(stderr,"File is not BSV2 format!\n");
		return NULL;
	}


	/*second line is number of vertices*/
	if(fscanf(file,"%d\n",&numVertices) == EOF)
	{
		fprintf(stderr,"File Read error!!\n");
		return NULL;
	}

	if(numVertices <=0)
	{
		fprintf(stderr,"You can't have less than 0 vertices!");
		return NULL;
	}

	/*second line is number of vertices*/
	if(fscanf(file,"%d\n",&numTris) == EOF)
	{
		fprintf(stderr,"File Read error!!\n");
		return NULL;
	}

	/*next is numVertices number of lines to fill up the shape with.*
	 * Create the shape now.*/
	shape = createShape(numVertices,numTris);

	for(i=0;i<numVertices;i++)
	{
		if(fscanf(file,"%f %f %f\n",&(shape->vTable[i*3]),
				    &(shape->vTable[i*3 + 1]),
				    &(shape->vTable[i*3 + 2]))
		   == EOF)
		{
			destroyShape(shape);
			fprintf(stderr,"Read error in vTable read\n");
			return NULL;
		}
	}

	/*next up is to take in numVertices*2 -4 number of triangles*/
	numVertices = numTris;
	for(i=0;i<numVertices;i++)
	{
		if(fscanf(file,"%d %d %d\n",&(shape->tTable[i*3]),
				    &(shape->tTable[i*3 + 1]),
				    &(shape->tTable[i*3 + 2]))
		   == EOF)
		{
			destroyShape(shape);
			fprintf(stderr,"Read error in tTable read\n");
			return NULL;
		}

	}
	fclose(file);

	return shape;
}

int numTriangles(Shape shape)
{
/*	return (2*shape->numVertices)-4;*/
	return shape->numTris;
}

int writeShapeToFile(Shape shape, char* fileName)
{
	FILE* file;
	int i;

	if(shape==NULL)
		return 1;

	if(fileName == NULL)
		return 1;

	file = fopen(fileName,"w");
	if(file == NULL)
	{
		fprintf(stderr,"Unable to open %s for writing.\n",fileName);
		return 2;
	}

	/*First write BSV1*/
	fprintf(file,"BSV2\n");

	/*then write the number of vertices*/
	fprintf(file,"%d\n",shape->numVertices);

	/*then write the number of vertices*/
	fprintf(file,"%d\n",shape->numTris);

	/*then list all of the vertices*/
	for(i=0;i<shape->numVertices;i++)
	{
		fprintf(file,"%f %f %f\n",shape->vTable[i*3],
					shape->vTable[i*3 + 1],
					shape->vTable[i*3 + 2]);
	}

	/*then list all the triangles*/
	for(i=0;i<numTriangles(shape);i++)
	{
		fprintf(file,"%d %d %d\n",shape->tTable[i*3],
					  shape->tTable[i*3+1],
				  	  shape->tTable[i*3+2]);
        }

	fclose(file);
	return 0;
}

/*the main function -- main*/
/*int main(int argc,char ** argv)
{
	Shape inShape; 
	Shape outShape;

	if(argc != 3)
	{
		fprintf(stderr,"\nfileSmoother - Team Greenlee\n"
			       "Usage:\n\tfileSmoother inFile outFile\n\n");
		return 1;
	}

	inShape = readShapeFromFile(argv[1]);
	if(inShape == NULL)
	{
		fprintf(stderr,"Read failure.\n");
		return 1;
	}	
	if(writeShapeToFile(inShape,argv[2]) != 0)
	{
		fprintf(stderr,"Write failure.\n");
		return 2;
	}
	return 0;
}*/
