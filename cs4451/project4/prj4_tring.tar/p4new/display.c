#include "defs.h"

/* ambient light in direction (10, 10, 10) */
GLfloat light1_x = 10.0;
GLfloat light1_y = 10.0;
GLfloat light1_z = 10.0;

/* eye point coordinates for view */
GLfloat eye_x = 0.0001;
GLfloat eye_y = 0;
GLfloat eye_z = 20;
GLfloat set_eye_x = 0.0001;
GLfloat set_eye_y = 0;
GLfloat set_eye_z = 20;

extern GLfloat startX, startY, endX, endY;

/*
 * OpenGL commands
 */
void init(void)
{    
  glClearColor (0.0, 0.0, 0.0, 0.0);
  glShadeModel(GL_FLAT);
  glEnable(GL_DEPTH_TEST);
  glDepthFunc(GL_LEQUAL);

  /* lighting stuff */
  glShadeModel (GL_SMOOTH);


  glEnable(GL_LIGHTING);  /* enable lighting */
  glEnable(GL_LIGHT0);    /* enable light0 */
  glEnable(GL_NORMALIZE);
}

void display()
{
  GLfloat light_position[] = {0.0,0.0,0.0,0.0};

  light_position[0] = light1_x;
  light_position[1] = light1_y;
  light_position[2] = light1_z;

  /* this will be your shadow matrix.  You need to specify what this contains.
   * OpenGL has a funky ordering for rows and columns
   * use this ordering for rows and columns.  
   * The identity matrix with Mr,c = M3,3 = 0;
   */
  M[0]= 1; M[4]= 0; M[8] =(-1*(light1_x)/light1_z); M[12]= 0;
  M[1]= 0; M[5]= 1; M[9] =(-1*(light1_y)/light1_z); M[13]= 0;
  M[2]= 0; M[6]= 0; M[10]= 0;                       M[14]= 0;
  M[3]= 0; M[7]= 0; M[11]= 0;                       M[15]= 1;


  /* specular highlights have color 'mat_specular'*/
  glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);

  /* shininess ('N') = mat_shininess*/
  glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);

  /* replaces the matrix in the top of the stack with the identity matrix */
  glLoadIdentity(); 

  /* multiplies the current matrix by a tranformation matrix that puts the 
   * eyepoint 
   * at <10,0,5>, center of the image at <0,0,0>, and up vector of <0,0,1> 
   * (z-axis).
   */
  if (glutGetWindow() == window_main) {
    gluLookAt(set_eye_x,set_eye_y,set_eye_z, 0,0,0, 0,0,1); 
  }
  else {
    gluLookAt(eye_x,eye_y,eye_z, 0,0,0, 0,0,1); 
  }
  /* move light0 to 'light_position' */
  glLightfv(GL_LIGHT0, GL_POSITION, light_position); 

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  
  /* initialize the quadric object */
  quadObj = gluNewQuadric();

  /* Draws the TRING Board */
  drawBoard();

  /* Displays the cue arrow */
  display_arrow();

  /* specular highlights have color 'mat_specular'*/
  glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);

  /* shininess ('N') = mat_shininess*/
  glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);


  /* Display the balls */
  drawPoolBall(red_pos[X],red_pos[Y], mat_red);
  drawPoolBall(yellow_pos[X],yellow_pos[Y], mat_yellow);
  drawPoolBall(blue_pos[X],blue_pos[Y], mat_blue);
  
  glutSwapBuffers();    
  glFlush();
}


void keyboard (unsigned char key, int x, int y)
{
  /* Keyboard keys that move the view and light position */
   switch (key) {
      case 27:
         exit(0);
         break;
      case 'w':
         light1_x++;
         break;
      case 's':
         light1_x--;
         break;
      case 'd':
         light1_y++;
         break;
      case 'a':
         light1_y--;
         break;
      case 'j':
         eye_x--;
         break;
      case 'l':
         eye_x++;
         break;
      case 'i':
         eye_y++;
         break;
      case 'k':
         eye_y--;
         break;
      case 'u':
         eye_z--;
         break;
      case 'o':
         eye_z++;
         break;
      default:
         break;
   }
   glutPostRedisplay();
}

void display_arrow()
{
  glPushMatrix();
   glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, mat_white);
   glTranslatef(0,0,0.1);
   glBegin(GL_POLYGON);
    glVertex3f(startX, startY, 1);
    glVertex3f(startX-0.1, startY, 1);
    glVertex3f(endX-0.1, endY, 1);
    glVertex3f(endX+0.1, endY, 1);
    glVertex3f(startX+0.1, startY, 1);
   glEnd();
  glPopMatrix();
}

void display_3d() 
{
  gluLookAt(eye_x+5,eye_y+5,eye_z, 0,0,0, 0,0,1); 
  display();
}

/* Functions for setting up score window */
void renderBitmapString(float x, float y, void *font,char *string)
{  
  char *c;
  glRasterPos2f(x, y);
  for (c=string; *c != '\0'; c++) {
    glutBitmapCharacter(font, *c);
  }
}

void draw_text(GLint x, GLint y, char* s, GLfloat r, GLfloat g, GLfloat b)
{
  int lines;
  char* p;
  
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glLoadIdentity();
  glOrtho(0.0, glutGet(GLUT_WINDOW_WIDTH), 
	  0.0, glutGet(GLUT_WINDOW_HEIGHT), -1.0, 1.0);
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
  glLoadIdentity();
  glColor3f(r,g,b);
  glRasterPos2i(x, y);
  for(p = s, lines = 0; *p; p++) {
    if (*p == '\n') {
      lines++;
      glRasterPos2i(x, y-(lines*18));
    }
    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *p);
  }
  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glMatrixMode(GL_MODELVIEW);
}

void display_score() 
{
  char player1[20];
  char player2[20];
  char ball[20];
  char turnstr[20];
  char *color = " ";
  
  switch(turn){
  case YELLOW:
    color = "Yellow";
    break;
  case BLUE:
    color = "Blue";
    break;
  case RED:
    color = "Red";
  default:
    break;
  }

  sprintf(ball, "Ball: %s", color);
  sprintf(turnstr, "Turn: Player %d", player);
  sprintf(player1, "Player 1: %d", p1score);
  sprintf(player2, "Player 2: %d", p2score);

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  draw_text(5, 70, turnstr, 1.0, 0.0, 0.0);
  draw_text(5, 50, ball, 1.0, 0.0, 0.0); 
  draw_text(5, 30, player1, 1.0, 0.0, 0.0);
  draw_text(5, 10, player2, 1.0, 0.0, 0.0);

  glutSwapBuffers();
}


/*********************************************************/
/********************* DRAWING ***************************/
/*********************************************************/


/* Draws the green circular carum table with border and bumpers */
void drawBoard()
{
  GLfloat mat_border[] = {0.6, 0.6, 0.6, 0.0};

  glPushMatrix();  
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_black);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_black);

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, mat_border);

    glTranslatef(0,0,0.3);
    gluDisk(quadObj, 10, 10.5, 70, 70);

    glTranslatef(0,0,-0.4);
    gluCylinder( quadObj, 10, 10, 0.4, 50, 50);

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, mat_green);
    gluDisk(quadObj, 0, 10, 50, 50);

  glPopMatrix();
}

/* Generic ball drawing function that also displays the balls' shadows */
void drawPoolBall(float x, float y, float mat_color[])
{
  glPushMatrix();  
  glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, mat_color);
   glTranslatef(x, y, 0.5);
   gluSphere(quadObj, ball_r, 20, 20);
  glPopMatrix();

  glPushMatrix();
  glMultMatrixf(M);
   glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, mat_black);
   glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_black);
   glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_black);

   glTranslatef( x, y, 0.5);
   gluSphere(quadObj, ball_r, 20, 20);
   
  glPopMatrix();

  /* specular highlights have color 'mat_specular'*/
  glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);

  /* shininess ('N') = mat_shininess*/
  glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);
}
