#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <stdio.h>
#include "shape.h"

/* you may need to locate glut.h on your computer and change the path accordingly
 It is most likely in ~/include or ~include/GL.
 */

/* the viewport is 500x500 with the origin at (0,0) */
int Vx_min=0, Vx_max=500, Vy_min=0, Vy_max=500, Vz_min=0, Vz_max=0;


void init(void) 
{
   glClearColor (0.0, 0.0, 0.0, 0.0);
}

Shape shape;
Shape shape2;
void display(void)
{
	int i;

	glClear (GL_COLOR_BUFFER_BIT);   

	/* green */
	glColor3f(0.0,1.0,0.0); /* params are floats in range [0.0,1.0] */


	glLoadIdentity ();             /* clear the matrix */
	  /* viewing transformation  */
	gluLookAt (5.0, 5.0, 7.0, 0.0, 0.0, 2.0, 0.0, 1.0, 0.0);
	glScalef (1.0, 2.0, 1.0);      /* modeling transformation */

	/* draws one or more triangles */
	if(shape!=NULL)
	{
		glColor3f(0.0,1.0,0.0);
	        for(i=0;i<numTriangles(shape);i++)
        	{
               	 glBegin(GL_LINE_STRIP);
                        glVertex3f(shape->vTable[3*shape->tTable[i*3]],
                                   shape->vTable[3*shape->tTable[i*3]+1],
                                   shape->vTable[3*shape->tTable[i*3]+2]);
                        glVertex3f(shape->vTable[3*shape->tTable[i*3+1]],
                                   shape->vTable[3*shape->tTable[i*3+1]+1],
                                   shape->vTable[3*shape->tTable[i*3+1]+2]);
                        glVertex3f(shape->vTable[3*shape->tTable[i*3+2]],
                                   shape->vTable[3*shape->tTable[i*3+2]+1],
                                   shape->vTable[3*shape->tTable[i*3+2]+2]);
                        glVertex3f(shape->vTable[3*shape->tTable[i*3]],
                                   shape->vTable[3*shape->tTable[i*3]+1],
                                   shape->vTable[3*shape->tTable[i*3]+2]);
		 /*printf("Drawing Triangle %f %f %f, %f %f %f, %f %f %f\n",
                        shape->vTable[shape->tTable[i*3]],
                                   shape->vTable[shape->tTable[i*3]+1],
                                   shape->vTable[shape->tTable[i*3]+2],
                        shape->vTable[shape->tTable[i*3+1]],
                                   shape->vTable[shape->tTable[i*3+1]+1],
                                   shape->vTable[shape->tTable[i*3+1]+2],
                        shape->vTable[shape->tTable[i*3+2]],
                                   shape->vTable[shape->tTable[i*3+2]+1],
                                   shape->vTable[shape->tTable[i*3+2]+2]);*/
                 glEnd();
		 glFlush();
		}
	}
	if(shape2 != NULL)
	{
		glColor3f(1.0,0.0,0.0);
	        for(i=0;i<numTriangles(shape2);i++)
        	{
               	 glBegin(GL_LINE_STRIP);
                        glVertex3f(shape2->vTable[3*shape2->tTable[i*3]],
                                   shape2->vTable[3*shape2->tTable[i*3]+1],
                                   shape2->vTable[3*shape2->tTable[i*3]+2]);
                        glVertex3f(shape2->vTable[3*shape2->tTable[i*3+1]],
                                   shape2->vTable[3*shape2->tTable[i*3+1]+1],
                                   shape2->vTable[3*shape2->tTable[i*3+1]+2]);
                        glVertex3f(shape2->vTable[3*shape2->tTable[i*3+2]],
                                   shape2->vTable[3*shape2->tTable[i*3+2]+1],
                                   shape2->vTable[3*shape2->tTable[i*3+2]+2]);
                        glVertex3f(shape2->vTable[3*shape2->tTable[i*3]],
                                   shape2->vTable[3*shape2->tTable[i*3]+1],
                                   shape2->vTable[3*shape2->tTable[i*3]+2]);
		glEnd();
		glFlush();
		}
	}
	/*glutWireCube (1.0); */ 
	glFlush ();
}

void reshape (int w, int h)
{
   
   glViewport (0, 0, (GLsizei) w, (GLsizei) h); 
   glMatrixMode (GL_PROJECTION);
   glLoadIdentity ();
   //gluOrtho2D(Vx_min, Vx_max, Vy_min, Vy_max);
   //glOrtho(-500.0, 500.0, -500.0, 500.0, -500.0, 500.0);
   gluPerspective(90, 1, 1, 1000);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity ();
}
void mouse(int button, int state, int x, int y)
{

   switch (button) {
      case GLUT_LEFT_BUTTON:
		  if (state == GLUT_DOWN) {
			printf("left mouse click\n");
			glutPostRedisplay();
		  }
         break;
      default:
         break;
   }
}

int main(int argc, char** argv)
{
   int c;

   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
   glutInitWindowSize (Vx_max-Vx_min, Vy_max-Vy_min); 
   glutInitWindowPosition (100, 100);
   glutCreateWindow (argv[0]);
   
   if(argc > 3)
   {
	printf("Usage: %s fileName\n",argv[0]);
 	return 1;
   } 
   if(argc > 1)
   	shape = readShapeFromFile(argv[1]);
   if(argc > 2)
	shape2 = readShapeFromFile(argv[2]);
   if(shape == NULL)
	return 1;

   init ();

   glutDisplayFunc(display); 
   glutReshapeFunc(reshape);
   glutMouseFunc(mouse);
   glutMainLoop();
   return 0;
}
